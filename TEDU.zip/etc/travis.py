#!/usr/bin/env python3

from travis.DeploymentTester import DeploymentTester

DeploymentTester().run()
