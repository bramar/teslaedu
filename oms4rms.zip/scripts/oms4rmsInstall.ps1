$script:exitCode = ( Start-Process -File .\OMS4RMS_Setup.msi -ArgumentList "/passive" -PassThru -Wait).ExitCode

$running = $true;
while ($running -eq $true) {
    $running = ( ( Get-Process | where ProcessName -eq "setup").Length -gt 0);
    Start-Sleep -s 5
}
.\oms4rms.ps1
