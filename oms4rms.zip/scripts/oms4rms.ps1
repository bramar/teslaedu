﻿Set-ExecutionPolicy -Scope CurrentUser Unrestricted
$Folder = "Comtrade"
$Name = "OMS4RMS Configuration"
$BasePath = "$env:ALLUSERSPROFILE\Microsoft\Windows"
$Shortcut = "$BasePath\Start Menu\Programs\$Folder\$Name.lnk"
$Target = "C:\Program Files (x86)\Comtrade\OMS4RMS\OMS4RMS_Config.exe"

if (Test-Path -Path "$Shortcut") {
    Remove-Item -Path "$Shortcut" -Force -ErrorAction SilentlyContinue
}

if (!(Test-Path -Path "$BasePath\Start Menu\Programs\$Folder")) {
    $null = New-Item -Path "$BasePath\Start Menu\Programs\$Folder" -ItemType Directory -Force
}

$WshShell = New-Object -ComObject WScript.Shell
$ObjShortCut = $WshShell.CreateShortcut($Shortcut)
$ObjShortCut.TargetPath = $Target
$ObjShortCut.IconLocation = "C:\Program Files (x86)\Comtrade\OMS4RMS\favicon_250x250_K7B_icon.ico"
$ObjShortCut.Description="OMS4RMS Configuration"
$ObjShortCut.Save()

$Shortcut = "$env:Public\Desktop\$Name.lnk"
$WshShell = New-Object -ComObject WScript.Shell
$ObjShortCut = $WshShell.CreateShortcut($Shortcut)
$ObjShortCut.TargetPath = $Target
$ObjShortCut.IconLocation = "C:\Program Files (x86)\Comtrade\OMS4RMS\favicon_250x250_K7B_icon.ico"
$ObjShortCut.Description="OMS4RMS Configuration"
$ObjShortCut.Save()

$RunOnceKey = "HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce"
set-itemproperty $RunOnceKey "NextRun" ('C:\Program Files (x86)\Comtrade\OMS4RMS\OMS4RMS_Config.exe')
